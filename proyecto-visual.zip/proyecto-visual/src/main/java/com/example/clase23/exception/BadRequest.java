package com.example.clase23.exception;

public class BadRequest extends Exception{
    public BadRequest(String message){
        super(message);
    }
}
