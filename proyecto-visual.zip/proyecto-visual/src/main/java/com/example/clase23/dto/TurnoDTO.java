package com.example.clase23.dto;

import java.time.LocalDate;

public class TurnoDTO {
    private Long id;
    private LocalDate fechaTurno;
    private Long PacienteId;
    private Long OdontologoId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getFecha() {
        return fechaTurno;
    }

    public void setFecha(LocalDate fechaTurno) {
        this.fechaTurno = fechaTurno;
    }

    public Long getPacienteId() {
        return PacienteId;
    }

    public void setPacienteId(Long pacienteId) {
        PacienteId = pacienteId;
    }

    public Long getOdontologoId() {
        return OdontologoId;
    }

    public void setOdontologoId(Long odontologoId) {
        OdontologoId = odontologoId;
    }
}
