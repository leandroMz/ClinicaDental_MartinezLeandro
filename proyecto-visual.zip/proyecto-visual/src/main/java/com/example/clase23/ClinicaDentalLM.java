package com.example.clase23;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClinicaDentalLM {
	public static void main(String[] args) {
		SpringApplication.run(ClinicaDentalLM.class, args);
	}

}
