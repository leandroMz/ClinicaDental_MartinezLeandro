package com.example.clase23.entity;

public enum UsuarioRol {
    ROLE_USER,
    ROLE_ADMIN
}
