const formulario = document.querySelector('#formulario');
formulario.addEventListener('submit', function (event) {
    event.preventDefault();
    const fechaTurno = document.querySelector('#fechaTurno').value;
    const PacienteId = document.querySelector('#PacienteId').value;
    const OdontologoId = document.querySelector('#OdontologoId').value;


    if (fechaTurno.trim() === "" || PacienteId.trim() === "" || OdontologoId.trim() === "") {
        return;
    }

    fetch('/turnos', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          "fechaTurno": fechaTurno,
            "PacienteId": PacienteId,
            "OdontologoId": OdontologoId
        })
    })
    .then((response) => {
        if (response.ok) {
            Swal.fire({
                title: 'Turno registrado',
                text: 'El turno ha sido registrado correctamente',
                icon: 'success',
                footer: '<a href="/html/getTurno.html">Ver Turnos</a>'

            });
            resetForm();
        } else {
            Swal.fire({
                title: 'Error al registrar turno',
                text: 'No se ha podido registrar el turno. Verifica los campos y vuelve a intentarlo',
                icon: 'error'
            });
        }
    })
    .catch((error) => {
        console.error(error);
    });
    console.log("enviado a base de datos");
});